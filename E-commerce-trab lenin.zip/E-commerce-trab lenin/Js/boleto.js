document.getElementById('payment-btn').addEventListener('click', function() {
    // ... (rest of your button click logic)

    // Show the barcode image
    document.querySelector('.brcode').style.display = 'block';
});