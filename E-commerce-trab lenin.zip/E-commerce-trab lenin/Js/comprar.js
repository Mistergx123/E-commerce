/*-----------------------------------------------------------------------------------*/
/*Aqui faz aparecer a mensagem quando envia o numero do WhatsApp */ 
const sendButton = document.querySelector('.form button.normal');

sendButton.addEventListener('click', function (event) {
    event.preventDefault(); 

    const phoneInput = document.querySelector('.form input[type="tel"]');
    const phoneNumber = phoneInput.value.trim();

    if (phoneNumber) {
        alert('Seu número foi enviado com sucesso! Obrigado por se inscrever.');
        phoneInput.value = '';
    } else {
        alert('Por favor, insira um número de telefone válido.');
    }
});

let iconCart = document.querySelector('.iconCart');
let cart = document.querySelector('.cart');
let container = document.querySelector('.container');
let close = document.querySelector('.close');

iconCart.addEventListener('click', function(){
    if(cart.style.right == '-100%'){
        cart.style.right = '0';
        container.style.transform = 'translateX(-400px)';
    }else{
        cart.style.right = '-100%';
        container.style.transform = 'translateX(0)';
    }
});

close.addEventListener('click', function (){
    cart.style.right = '-100%';
    container.style.transform = 'translateX(0)';
});

let comprar = null;
// get data from file comprar.json
fetch('../json/comprar.json')
    .then(response => response.json())
    .then(data => {
        comprar = data;
        addDataToHTML();
});

// Show datas from comprar in list 
function addDataToHTML() {
    let listProductHTML = document.querySelector('.listProduct');
    listProductHTML.innerHTML = ''; // Limpa os dados existentes

    if (comprar != null) {
        comprar.forEach(item => {
            let newProduct = document.createElement('div');
            newProduct.classList.add('item');
            newProduct.innerHTML = `
                <img src="${item.image}" alt="">
                <h2>${item.name}</h2>
                <div class="price">${formatPrice(item.price)}</div>
                <button onclick="addCart(${item.id})">Adicionar ao Carrinho</button>`;
            listProductHTML.appendChild(newProduct);
        });
    }
}

// Função para formatar preços em moeda brasileira
function formatPrice(price) {
    return price.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

// Usar cookie para o carrinho não se perder ao atualizar a página
let listCart = [];
function checkCart() {
    var cookieValue = document.cookie
    .split('; ')
    .find(row => row.startsWith('listCart='));
    if(cookieValue){
        listCart = JSON.parse(cookieValue.split('=')[1]);
    } else {
        listCart = [];
    }
}
checkCart();

function addCart($idItem) {
    let comprarCopy = JSON.parse(JSON.stringify(comprar));
    // Se o item não estiver no carrinho
    if (!listCart[$idItem]) {
        listCart[$idItem] = comprarCopy.filter(item => item.id == $idItem)[0];
        listCart[$idItem].quantity = 1;
    } else {
        // Se o item já estiver no carrinho, aumente a quantidade
        listCart[$idItem].quantity++;
    }
    document.cookie = "listCart=" + JSON.stringify(listCart) + "; expires=Thu, 31 Dec 2025 23:59:59 UTC; path=/;";

    addCartToHTML();
}

addCartToHTML();

function addCartToHTML() {
    let listCartHTML = document.querySelector('.listCart');
    listCartHTML.innerHTML = ''; // Limpa os dados existentes

    let totalHTML = document.querySelector('.totalQuantity');
    let priceHTML = document.querySelector('.totalPrice');
    let totalQuantity = 0;
    let totalPrice = 0;

    if (listCart) {
        listCart.forEach(item => {
            if (item) {
                let newCart = document.createElement('div');
                newCart.classList.add('item');
                newCart.innerHTML = `
                    <img src="${item.image}">
                    <div class="content">
                        <div class="name">${item.name}</div>
                        <div class="price">${formatPrice(item.price)} / 1 produto</div>
                    </div>
                    <div class="quantity">
                        <button onclick="changeQuantity(${item.id}, '-')">-</button>
                        <span class="value">${item.quantity}</span>
                        <button onclick="changeQuantity(${item.id}, '+')">+</button>
                    </div>
                    <div class="returnPrice">${formatPrice(item.price * item.quantity)}</div>`;
                listCartHTML.appendChild(newCart);
                totalQuantity += item.quantity;
                totalPrice += item.price * item.quantity;
            }
        });
    }

    totalHTML.innerText = totalQuantity;
    priceHTML.innerText = formatPrice(totalPrice);
}

function changeQuantity($idItem, $type) {
    switch ($type) {
        case '+':
            listCart[$idItem].quantity++;
            break;
        case '-':
            listCart[$idItem].quantity--;

            // Se a quantidade for menor ou igual a 0, remove o produto do carrinho
            if (listCart[$idItem].quantity <= 0) {
                delete listCart[$idItem];
            }
            break;

        default:
            break;
    }
    // Salva os novos dados no cookie
    document.cookie = "listCart=" + JSON.stringify(listCart) + "; expires=Thu, 31 Dec 2025 23:59:59 UTC; path=/;";
    // Atualiza a visualização do carrinho
    addCartToHTML();
}
