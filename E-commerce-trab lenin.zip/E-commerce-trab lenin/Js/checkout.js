let listCart = [];

// Função para verificar o carrinho usando cookies
function checkCart() {
    const cookieValue = document.cookie
        .split('; ')
        .find(row => row.startsWith('listCart='));
    if (cookieValue) {
        listCart = JSON.parse(cookieValue.split('=')[1]);
    }
}
checkCart();
addCartToHTML();

// Função para formatar preços no formato brasileiro
function formatPrice(price) {
    return price.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

// Função para atualizar o carrinho no HTML
function addCartToHTML() {
    // Limpa os dados existentes
    let listCartHTML = document.querySelector('.returnCart .list');
    listCartHTML.innerHTML = '';

    let totalQuantityHTML = document.querySelector('.totalQuantity');
    let totalPriceHTML = document.querySelector('.totalPrice');

    let totalQuantity = 0;
    let totalPrice = 0;

    // Verifica se há produtos no carrinho
    if (listCart) {
        listCart.forEach(product => {
            if (product) {
                let newCart = document.createElement('div');
                newCart.classList.add('item');
                newCart.innerHTML = `
                    <img src="${product.image}">
                    <div class="info">
                        <div class="name">${product.name}</div>
                        <div class="price">${formatPrice(product.price)} / 1 produto</div>
                    </div>
                    <div class="quantity">${product.quantity}</div>
                    <div class="returnPrice">${formatPrice(product.price * product.quantity)}</div>`;
                listCartHTML.appendChild(newCart);

                totalQuantity += product.quantity;
                totalPrice += product.price * product.quantity;
            }
        });
    }

    // Atualiza as informações de total de itens e preço
    totalQuantityHTML.innerText = totalQuantity;
    totalPriceHTML.innerText = formatPrice(totalPrice);
}

document.getElementById('checkoutButton').addEventListener('click', function(event) {
    event.preventDefault(); // Prevents the default action of the link
    
    // Display the "Pedido Feito" message
    alert("Pedido feito!");

    // Clear the cart
    const cartItems = document.querySelector('.list');
    cartItems.innerHTML = ''; // Clears all cart items
    
    // Optionally, you could update the total quantity and price as well
    document.querySelector('.totalQuantity').textContent = '0';
    document.querySelector('.totalPrice').textContent = '$0';

    // Optionally, redirect after a small delay
    setTimeout(function() {
        window.location.href = "index.html"; // Redirect to the main page after the message
    }, 1500); // 1.5 seconds delay to show the alert
});
