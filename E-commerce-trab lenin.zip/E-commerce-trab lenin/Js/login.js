document.addEventListener("DOMContentLoaded", () => {
    const track = document.querySelector(".carousel-track");
    const images = document.querySelectorAll(".carousel img");
    const totalImages = images.length;
    let currentIndex = 0;
  
    // Função para alternar entre as imagens
    setInterval(() => {
      currentIndex = (currentIndex + 1) % totalImages; // Avança no índice e reseta ao atingir o final
      track.style.transform = `translateX(-${currentIndex * 100}%)`; // Move o carrossel
    }, 1800); // Troca de imagem a cada 4 segundos
  });
  